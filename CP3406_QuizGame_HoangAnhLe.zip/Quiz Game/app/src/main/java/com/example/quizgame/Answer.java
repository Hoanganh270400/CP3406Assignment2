package com.example.quizgame;

import java.security.PublicKey;

public class Answer {
    private String content;
    private Boolean isCorrect;
    public Answer(String content, boolean isCorrect){
        this.content = content;
        this.isCorrect = isCorrect;
    }
    public String getContent(){
        return content;
    }
    public void setContent(String content){
        this.content = content;

    }
    public boolean isCorrect(){
        return isCorrect;
    }
    public void setIsCorrect(boolean correct){
        isCorrect = correct;
    }
}
