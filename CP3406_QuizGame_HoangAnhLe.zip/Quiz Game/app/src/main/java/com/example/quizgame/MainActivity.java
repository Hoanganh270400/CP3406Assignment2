package com.example.quizgame;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView tvQuestion;
    private TextView tvContentQuestion;
    private TextView tvAnswer1,tvAnswer2,tvAnswer3,tvAnswer4;
    private List<Question> mListQuestion;
    private Question mQuestion;
    private int currentQuestion =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUi();
        mListQuestion = getListQuestion();
        if (mListQuestion.isEmpty()){
            return;
        }
        setDataQuestion(mListQuestion.get(currentQuestion));

    }

    private void setDataQuestion(Question question) {
        if (question == null){
            return;
        }
        mQuestion = question;

        String titleQuestion = "Question" + question.getNumber();
        tvQuestion.setText(titleQuestion);
        tvContentQuestion.setText(question.getContent());
        tvAnswer1.setText(question.getListAnswer().get(0).getContent());
        tvAnswer2.setText(question.getListAnswer().get(1).getContent());
        tvAnswer3.setText(question.getListAnswer().get(2).getContent());
        tvAnswer4.setText(question.getListAnswer().get(3).getContent());

        tvAnswer1.setOnClickListener(this);
        tvAnswer2.setOnClickListener(this);
        tvAnswer3.setOnClickListener(this);
        tvAnswer4.setOnClickListener(this);

    }

    private void initUi (){
        tvQuestion = findViewById(R.id.tv_question);
        tvContentQuestion = findViewById(R.id.tv_content_question);
        tvAnswer1 = findViewById(R.id.tv_answer1);
        tvAnswer2 = findViewById(R.id.tv_answer2);
        tvAnswer3 = findViewById(R.id.tv_answer3);
        tvAnswer4 = findViewById(R.id.tv_answer4);

    }
    private List<Question> getListQuestion(){
        List<Question> list = new ArrayList<>();
        List<Answer> answersList1 = new ArrayList<>();
        answersList1.add(new Answer("Chicken",true));
        answersList1.add(new Answer("Fish",false));
        answersList1.add(new Answer("Pig",false));
        answersList1.add(new Answer("Cow",false));

        List<Answer> answersList2 = new ArrayList<>();
        answersList2.add(new Answer("Other bugs",false));
        answersList2.add(new Answer("Grass",false));
        answersList2.add(new Answer("Its own eggshell",true));
        answersList2.add(new Answer("Cheerios",false));

        List<Answer> answersList3 = new ArrayList<>();
        answersList3.add(new Answer("10",false));
        answersList3.add(new Answer("30",true));
        answersList3.add(new Answer("50",false));
        answersList3.add(new Answer("70",false));

        List<Answer> answersList4 = new ArrayList<>();
        answersList4.add(new Answer("Sheep",true));
        answersList4.add(new Answer("Skunk",false));
        answersList4.add(new Answer("Leopard",false));
        answersList4.add(new Answer("Tiger",false));

        List<Answer> answersList5 = new ArrayList<>();
        answersList5.add(new Answer("Doe",false));
        answersList5.add(new Answer("Buck",false));
        answersList5.add(new Answer("Kit",true));
        answersList5.add(new Answer("Hare",false));

        list.add(new Question(1,"Which one is a bird?",answersList1));
        list.add(new Question(2,"What's the first thing a caterpillar usually eats after it's born?",answersList2));
        list.add(new Question(3,"The trumpeter swan-North America's largest waterfowl-weighs about how many pounds?",answersList3));
        list.add(new Question(4,"Which of the following animals is not nocturnal?",answersList4));
        list.add(new Question(5,"What is baby rabbit called?",answersList5));
        return list;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_answer1:
                tvAnswer1.setBackgroundResource(R.drawable.bg_yellow_conner);
                checkAnswer(tvAnswer1, mQuestion, mQuestion.getListAnswer().get(0));
                break;
            case R.id.tv_answer2:
                tvAnswer2.setBackgroundResource(R.drawable.bg_yellow_conner);
                checkAnswer(tvAnswer2, mQuestion, mQuestion.getListAnswer().get(1));
                break;
            case R.id.tv_answer3:
                tvAnswer3.setBackgroundResource(R.drawable.bg_yellow_conner);
                checkAnswer(tvAnswer3, mQuestion, mQuestion.getListAnswer().get(2));
                break;
            case R.id.tv_answer4:
                tvAnswer4.setBackgroundResource(R.drawable.bg_yellow_conner);
                checkAnswer(tvAnswer4, mQuestion, mQuestion.getListAnswer().get(3));
                break;
        }

    }
    private void checkAnswer(TextView textView, Question question, Answer answer) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (answer.isCorrect()) {
                    textView.setBackgroundResource(R.drawable.bg_correct);
                    nextQuestion();
                }

                else {
                    textView.setBackgroundResource(R.drawable.bg_wrong);
                    showAnswerCorrect(question);
                    gameOver();
                }
            }
        }, 1000);
    }

    private void gameOver() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                showDialog("Game Over");
            }
        },1000);
    }

    private void showAnswerCorrect(Question question) {
        if (question == null || question.getListAnswer()==null|| question.getListAnswer().isEmpty()){
            return;
        }
        if (question.getListAnswer().get(0).isCorrect()){
            tvAnswer1.setBackgroundResource(R.drawable.bg_correct);

        } else if (question.getListAnswer().get(1).isCorrect()){
            tvAnswer2.setBackgroundResource(R.drawable.bg_correct);

        } else if (question.getListAnswer().get(2).isCorrect()){
            tvAnswer3.setBackgroundResource(R.drawable.bg_correct);

        } else  if (question.getListAnswer().get(3).isCorrect()){
            tvAnswer4.setBackgroundResource(R.drawable.bg_correct);

        }
    }

    private void nextQuestion() {
        if (currentQuestion == mListQuestion.size()-1){
            showDialog("You Win!!!");
        }
        else {
            currentQuestion++;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    setDataQuestion(mListQuestion.get(currentQuestion));;
                }
            },1000);

        }
    }


    private void showDialog(String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setCancelable(false);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                currentQuestion = 0;
                setDataQuestion(mListQuestion.get(currentQuestion));
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
